"""Smoke-check every route and record the requested prototype screenshots."""
from pathlib import Path
from urllib.parse import urlparse, unquote
from html.parser import HTMLParser
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).parent
SITE=ROOT/'site'
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  for key,value in attrs:
   if key in ('href','src') and value.startswith('/'):
    path=unquote(urlparse(value).path)
    dest=SITE/path.lstrip('/')
    if path.endswith('/'):dest=dest/'index.html'
    assert dest.exists(),f'Missing asset/link: {value}'
files=list(SITE.rglob('index.html'))
assert len(files)==34
for f in files:
 text=f.read_text(encoding='utf-8');Links().feed(text)
 assert 'noindex,follow' in text
 assert '\ufffd' not in text
report={'pages':len(files),'screenshots':[],'errors':[]}
with sync_playwright() as p:
 browser=p.chromium.launch()
 page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
 page.on('pageerror',lambda error:report['errors'].append(str(error)))
 for f in files:
  route='/'+f.parent.relative_to(SITE).as_posix().strip('.')+'/'
  route=route.replace('//','/')
  response=page.goto('http://127.0.0.1:8080'+route)
  assert response.status==200,route
  assert page.locator('h1').count()==1,route
 for width,label in [(1440,'desktop'),(390,'mobile')]:
  page.set_viewport_size({'width':width,'height':1000 if width==1440 else 844})
  for route,name in [('/','home'),('/places/wat-boromthat/','place'),('/map/','map'),('/eat/','eat')]:
   page.goto('http://127.0.0.1:8080'+route);page.evaluate('document.fonts.ready')
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(label,route,'overflow')
   file=QA/f'{name}-{label}.png';page.screenshot(path=str(file),full_page=True);report['screenshots'].append(file.name)
 page.goto('http://127.0.0.1:8080/eat/')
 page.locator('#shop-search').fill('ฮกกี่เหลา');assert page.locator('[data-shop]:visible').count()==1
 page.locator('#shop-search').fill('no-result-123');assert page.locator('#empty').is_visible()
 page.locator('#shop-search').fill('');page.locator('#shop-category').select_option('souvenir_shop');assert page.locator('[data-shop]:visible').count()==8
 page.goto('http://127.0.0.1:8080/map/');assert not page.locator('.map-panel').evaluate('(e)=>e.open');page.locator('summary').click();assert page.locator('.map-panel').evaluate('(e)=>e.open')
 assert page.locator('.map-panel svg a').count()==14
 page.goto('http://127.0.0.1:8080/');page.evaluate("document.documentElement.style.fontSize='200%'")
 assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
 browser.close()
assert not report['errors'],report['errors']
(QA/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
