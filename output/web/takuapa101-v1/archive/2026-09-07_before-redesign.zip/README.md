# ตะกั่วป่า 101 · Local prototype

Implemented the retained 2026-09-06 design plan as a static editorial website. All work stays within this project directory; the existing Siwara website is unchanged.

## Preview

Open http://localhost:8080/ while the local server is running.

```powershell
python build_site.py
python -m http.server 8080 --bind 127.0.0.1 --directory site
```

## Delivered

- 34 HTML pages: home, 20 places, 7 traditions, and 6 section indexes.
- 20 approved place assets, self-hosted WOFF2 fonts, responsive editorial CSS.
- Search and category filters for 59 source-listed businesses, including empty state.
- Municipal-map street trace, 14 linked place markers, accessible 20-place table, mobile map toggle.
- Configurable `SITE_BASE_URL`, canonical URLs, sitemap, structured data, and prototype `noindex`.
- Internal related-content mapping in `data/links.json`; map evidence and gaps in `data/map-gaps.md`.

## Validation

Run `python validate_site.py` with the server above running. The script requires Playwright and its Chromium browser.

All 34 routes returned HTTP 200. Internal page and asset paths passed. Desktop (1440px) and mobile (390px) screenshots for home, place, map, and directory are in `qa/`. Checks cover horizontal overflow, one heading per page, browser runtime errors, search, empty results, category filtering, and map toggle. Visual inspection covered the homepage, detail page, and map renders.

## Before launch

The prototype is local only; no deployment or domain change has been performed. Business operating status, visiting details, current event schedules, and six missing map positions remain unverified. Business map-marker colors and numbers need source matching before interactive shop pins can be added. Event detail pages intentionally contain only available source information; enrich them before opening production indexing. Confirm the domain and publication scope before changing noindex.
